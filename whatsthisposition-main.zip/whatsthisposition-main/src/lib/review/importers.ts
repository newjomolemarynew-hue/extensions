/**
 * Fetches a player's recent games from Lichess and Chess.com, or one game by link.
 * No key is needed:
 *   Lichess    lichess.org/api/games/user/{name} (ndjson) · lichess.org/game/export/{id} ·
 *              lichess.org/api/study/{study}/{chapter}.pgn (a study's or broadcast's game)
 *   Chess.com  api.chess.com/pub/player/{name}/games/archives → monthly archive ·
 *              www.chess.com/callback/{live|daily}/game/{id} (the JSON its game page loads)
 * `fetch` is injected so the parsing can be tested without the network.
 */
import { SITE_ASCII, SITE_URL } from "../brand";
import { chessComGameRef, gameFromCallback, type ChessComCallback } from "./chesscomGame";

export type Site = "lichess" | "chesscom";

export interface GameSummary {
  id: string;
  site: Site;
  url: string;
  white: string;
  black: string;
  whiteElo?: number;
  blackElo?: number;
  /** "1-0", "0-1", "1/2-1/2" or "*". */
  result: string;
  /** Epoch milliseconds. */
  playedAt?: number;
  speed?: string;
  opening?: string;
  pgn: string;
}

export class ImportError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}

type Fetch = (url: string, init?: RequestInit) => Promise<Response>;

const USER_AGENT = `${SITE_ASCII} game review (+${SITE_URL})`;

/** Usernames on both sites: letters, digits, _ and -, 2–30 characters. */
export function validUsername(name: string): boolean {
  return /^[A-Za-z0-9][A-Za-z0-9_-]{1,29}$/.test(name);
}

/** Lichess pages whose address looks like a game's (eight letters) but isn't one. */
const LICHESS_PAGES = new Set(["analysis", "practice", "training", "streamer", "features", "insights", "download"]);

/** A Lichess game id from a game link (lichess.org/abcd1234, …/abcd1234/black, …/abcd1234wxyz, …/embed/game/abcd1234). */
export function lichessGameId(text: string): string | null {
  const m = text.trim().match(/^(?:https?:\/\/)?(?:www\.)?lichess\.org\/(?:game\/export\/|embed\/(?:game\/)?)?([A-Za-z0-9]{8})(?:[A-Za-z0-9]{4})?(?:[/?#].*)?$/);
  return m && !LICHESS_PAGES.has(m[1]) ? m[1] : null;
}

/** A game in a Lichess study or broadcast (each broadcast round is a study, each game a chapter). */
export function lichessChapterRef(text: string): { study: string; chapter: string } | null {
  const m = text.trim().match(/lichess\.org\/(?:study|broadcast\/[^/?#\s]+\/[^/?#\s]+)\/([A-Za-z0-9]{8})\/([A-Za-z0-9]{8})(?:[/?#]|$)/);
  return m ? { study: m[1], chapter: m[2] } : null;
}

/** A player's profile or games page (lichess.org/@/name, chess.com/member/name …): that player's games. */
export function profileLink(text: string): { site: Site; user: string } | null {
  const t = text.trim();
  const m =
    t.match(/lichess\.org\/@\/([A-Za-z0-9_-]+)/) ??
    t.match(/chess\.com\/(?:members?|player|games\/archive|stats\/(?:live|daily)\/[a-z0-9_]+)\/([A-Za-z0-9_-]+)/i);
  if (!m || !validUsername(m[1])) return null;
  return { site: t.includes("lichess.org") ? "lichess" : "chesscom", user: m[1] };
}

interface LichessPlayer {
  user?: { name?: string };
  aiLevel?: number;
  rating?: number;
}

interface LichessGame {
  id: string;
  variant?: string;
  speed?: string;
  createdAt?: number;
  lastMoveAt?: number;
  status?: string;
  winner?: "white" | "black";
  players?: { white?: LichessPlayer; black?: LichessPlayer };
  opening?: { name?: string };
  pgn?: string;
}

const lichessName = (p?: LichessPlayer) => p?.user?.name ?? (p?.aiLevel ? `Stockfish level ${p.aiLevel}` : "Anonymous");

export function fromLichess(g: LichessGame): GameSummary | null {
  if (!g.pgn || (g.variant && g.variant !== "standard" && g.variant !== "fromPosition")) return null;
  const ongoing = g.status === "started" || g.status === "created";
  return {
    id: g.id,
    site: "lichess",
    url: `https://lichess.org/${g.id}`,
    white: lichessName(g.players?.white),
    black: lichessName(g.players?.black),
    whiteElo: g.players?.white?.rating,
    blackElo: g.players?.black?.rating,
    result: ongoing ? "*" : g.winner === "white" ? "1-0" : g.winner === "black" ? "0-1" : "1/2-1/2",
    playedAt: g.lastMoveAt ?? g.createdAt,
    speed: g.speed,
    opening: g.opening?.name,
    pgn: g.pgn,
  };
}

interface ChessComPlayer {
  username?: string;
  rating?: number;
  result?: string;
}

interface ChessComGame {
  url?: string;
  uuid?: string;
  pgn?: string;
  end_time?: number;
  time_class?: string;
  rules?: string;
  /** Link to the opening page, e.g. https://www.chess.com/openings/Pirc-Defense-Czech-Defense-4.f4 */
  eco?: string;
  white?: ChessComPlayer;
  black?: ChessComPlayer;
}

const DRAWN = new Set(["agreed", "repetition", "stalemate", "insufficient", "50move", "timevsinsufficient"]);

export function fromChessCom(g: ChessComGame): GameSummary | null {
  if (!g.pgn || (g.rules && g.rules !== "chess")) return null;
  const w = g.white?.result;
  const b = g.black?.result;
  const result = w === "win" ? "1-0" : b === "win" ? "0-1" : w && DRAWN.has(w) ? "1/2-1/2" : (g.pgn.match(/\[Result "([^"]+)"\]/)?.[1] ?? "*");
  const eco = (g.eco ?? g.pgn.match(/\[ECOUrl "([^"]+)"\]/)?.[1])?.match(/\/openings\/([^/?#]+)/)?.[1];
  return {
    id: g.uuid ?? g.url ?? String(g.end_time),
    site: "chesscom",
    url: g.url ?? "https://www.chess.com",
    white: g.white?.username ?? "White",
    black: g.black?.username ?? "Black",
    whiteElo: g.white?.rating,
    blackElo: g.black?.rating,
    result,
    playedAt: g.end_time ? g.end_time * 1000 : undefined,
    speed: g.time_class,
    // "Alapin-Sicilian-Defense-Barmen-Defense...10.O-O-Bxc3" → "Alapin Sicilian Defense Barmen Defense"
    opening: eco ? decodeURIComponent(eco).replace(/(?:\.{3}|-)\d+\..*$/, "").replace(/-/g, " ") : undefined,
    pgn: g.pgn,
  };
}

async function get(fetchImpl: Fetch, url: string, accept: string, token?: string): Promise<Response> {
  let res: Response;
  const headers: Record<string, string> = { Accept: accept, "User-Agent": USER_AGENT };
  if (token) headers.Authorization = `Bearer ${token}`;
  try {
    res = await fetchImpl(url, { headers, cache: "no-store" });
  } catch {
    throw new ImportError("Couldn't reach the chess site. Check your connection and try again.", 502);
  }
  if (res.status === 404) throw new ImportError("No such player or game was found.", 404);
  if (res.status === 429) throw new ImportError("The chess site is rate-limiting requests. Wait a minute and try again.", 429);
  if (!res.ok) throw new ImportError(`The chess site answered with an error (${res.status}).`, 502);
  return res;
}

/**
 * A Lichess player's recent games. Lichess lists them to anyone who asks for JSON lines
 * (`application/x-ndjson`); only the PGN form of the same endpoint answers 404 without
 * a login. A token (LICHESS_TOKEN) is optional and just raises the rate limit.
 */
export async function lichessUserGames(user: string, fetchImpl: Fetch = fetch, token?: string, max = 20): Promise<GameSummary[]> {
  if (!validUsername(user)) throw new ImportError("That isn't a valid Lichess username.");
  const url = `https://lichess.org/api/games/user/${encodeURIComponent(user)}?max=${max}&pgnInJson=true&opening=true&clocks=true&moves=true`;
  let res: Response;
  try {
    res = await get(fetchImpl, url, "application/x-ndjson", token);
  } catch (e) {
    if (e instanceof ImportError && e.status === 404) {
      const exists = await fetchImpl(`https://lichess.org/api/user/${encodeURIComponent(user)}`, { headers: { Accept: "application/json", "User-Agent": USER_AGENT } }).then(
        (r) => r.ok,
        () => false,
      );
      throw exists
        ? new ImportError(`Lichess didn't list ${user}'s games just now. Try again, or paste a Lichess game link (lichess.org/…) or the PGN.`, 502)
        : new ImportError(`No Lichess player called ${user}.`, 404);
    }
    throw e;
  }
  const text = await res.text();
  return text
    .split("\n")
    .filter((l) => l.trim())
    .map((l) => {
      try {
        return fromLichess(JSON.parse(l) as LichessGame);
      } catch {
        return null;
      }
    })
    .filter((g): g is GameSummary => !!g);
}

export async function lichessGame(id: string, fetchImpl: Fetch = fetch): Promise<GameSummary> {
  if (!/^[A-Za-z0-9]{8}$/.test(id)) throw new ImportError("That isn't a Lichess game link.");
  const url = `https://lichess.org/game/export/${id}?pgnInJson=true&opening=true&clocks=true`;
  const g = fromLichess((await (await get(fetchImpl, url, "application/json")).json()) as LichessGame);
  if (!g) throw new ImportError("That game isn't standard chess, so it can't be reviewed.");
  return g;
}

/** One game of a Lichess study or broadcast, by its chapter (public studies only). */
export async function lichessChapter(ref: { study: string; chapter: string }, fetchImpl: Fetch = fetch): Promise<GameSummary> {
  if (!/^[A-Za-z0-9]{8}$/.test(ref.study) || !/^[A-Za-z0-9]{8}$/.test(ref.chapter)) throw new ImportError("That isn't a Lichess study or broadcast game link.");
  const pgn = await (await get(fetchImpl, `https://lichess.org/api/study/${ref.study}/${ref.chapter}.pgn?clocks=true&comments=false&variations=false`, "application/x-chess-pgn")).text();
  const h = (k: string) => pgn.match(new RegExp(`^\\[${k} "([^"]*)"\\]`, "m"))?.[1];
  const variant = h("Variant");
  if (variant && !/^(standard|from position)$/i.test(variant)) throw new ImportError("That game isn't standard chess, so it can't be reviewed.");
  return {
    id: ref.chapter,
    site: "lichess",
    url: h("GameURL") ?? h("ChapterURL") ?? `https://lichess.org/study/${ref.study}/${ref.chapter}`,
    white: h("White") ?? "White",
    black: h("Black") ?? "Black",
    whiteElo: Number(h("WhiteElo")) || undefined,
    blackElo: Number(h("BlackElo")) || undefined,
    result: h("Result") ?? "*",
    opening: h("Opening"),
    pgn,
  };
}

export async function chessComUserGames(user: string, fetchImpl: Fetch = fetch, max = 20): Promise<GameSummary[]> {
  if (!validUsername(user)) throw new ImportError("That isn't a valid Chess.com username.");
  const base = `https://api.chess.com/pub/player/${encodeURIComponent(user.toLowerCase())}/games/archives`;
  const { archives = [] } = (await (await get(fetchImpl, base, "application/json")).json()) as { archives?: string[] };
  const out: GameSummary[] = [];
  // Newest month first; older months only if the latest one is thin.
  for (const month of archives.slice(-3).reverse()) {
    if (!/^https:\/\/api\.chess\.com\/pub\/player\//.test(month)) continue;
    const { games = [] } = (await (await get(fetchImpl, month, "application/json")).json()) as { games?: ChessComGame[] };
    for (const g of [...games].reverse()) {
      const s = fromChessCom(g);
      if (s) out.push(s);
    }
    if (out.length >= max) break;
  }
  return out.slice(0, max);
}

/**
 * One Chess.com game by link. The public API has no game-by-id endpoint, so this reads the
 * JSON Chess.com's own game page loads (as the extension does) and rebuilds the PGN from it.
 * A link that doesn't say live or daily (chess.com/game/123) is tried as both.
 */
export async function chessComGame(link: string, fetchImpl: Fetch = fetch): Promise<GameSummary> {
  const ref = chessComGameRef(link);
  if (!ref || !Number.isSafeInteger(ref.id)) throw new ImportError("That isn't a Chess.com game link.");
  const kinds = /chess\.com\/game\/\d/.test(link) ? (["live", "daily"] as const) : [ref.kind];
  const refused = new ImportError("Chess.com didn't hand over that game just now. Try again in a minute, or paste the game's PGN (Share → PGN).", 502);
  for (const kind of kinds) {
    let cb: ChessComCallback;
    try {
      cb = (await (await get(fetchImpl, `https://www.chess.com/callback/${kind}/game/${ref.id}`, "application/json")).json()) as ChessComCallback;
    } catch (e) {
      if (e instanceof ImportError && e.status === 404) continue;
      if (e instanceof ImportError && e.status !== 502) throw e;
      throw refused;
    }
    if (!cb?.game) throw refused;
    if (!cb.game.isFinished) throw new ImportError("That game hasn't finished yet. Review it once it's over.");
    if (!cb.game.moveList) throw new ImportError("That game has no moves to review.");
    const g = gameFromCallback(cb, kind);
    if (!g) throw new ImportError("That game isn't standard chess, so it can't be reviewed.");
    const h = cb.game.pgnHeaders ?? {};
    return {
      id: String(g.id),
      site: "chesscom",
      url: g.url,
      white: g.white,
      black: g.black,
      whiteElo: Number(h.WhiteElo) || undefined,
      blackElo: Number(h.BlackElo) || undefined,
      result: g.result,
      playedAt: g.endedAt ?? undefined,
      pgn: g.pgn,
    };
  }
  throw new ImportError("No Chess.com game was found at that link.", 404);
}
