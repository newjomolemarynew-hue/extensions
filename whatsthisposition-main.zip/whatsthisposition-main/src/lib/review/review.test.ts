import { describe, expect, it } from "vitest";
import openings from "@/data/openings.json";
import { START_FEN } from "../chess/fen";
import type { Evaluation } from "../engine/score";
import { gameAccuracy } from "./accuracy";
import { makeBook } from "./book";
import { classifyMove, decisiveSlope, expectedScore, gameRating, lossClass, moveAccuracy, type ClassifiedMove, type PositionAnalysis } from "./classify";
import { GAME_OF_THE_CENTURY, OPERA_GAME, SHILLING_TRAP } from "./fixtures/games";
import { mainLineTokens, parseFirstGame, parseGame, splitGames } from "./pgn";
import { analysePositions, classifyGame, criticalPositions, quietSearchPositions, runReview, searchQuietMoves } from "./review";
import { KASPAROV_TOPALOV } from "./samples";
import { detectSacrifice, see, unsafePieces } from "./safety";
import { placementFromFen } from "../chess/fen";

const book = makeBook(openings as { book: string[]; names: Record<string, string> });
const cp = (n: number): Evaluation => ({ kind: "cp", cp: n });
const pa = (e: Evaluation, pv: string[] = [], second?: Evaluation): PositionAnalysis => ({
  eval: e,
  depth: 14,
  lines: [{ multipv: 1, depth: 14, eval: e, pv }, ...(second ? [{ multipv: 2, depth: 14, eval: second, pv: ["a2a3"] }] : [])],
});
const moveAt = (pgn: string, ply: number) => parseGame(pgn).moves[ply - 1];

describe("PGN parsing", () => {
  it("parses headers, moves and results", () => {
    const g = parseGame(OPERA_GAME);
    expect(g.white).toBe("Paul Morphy");
    expect(g.moves).toHaveLength(33);
    expect(g.moves[32].san).toBe("Rd8#");
    expect(g.moves[32].isMate).toBe(true);
    expect(g.result).toBe("1-0");
  });

  it("drops variations, NAGs and comments but keeps clocks", () => {
    const { sans, clocks } = mainLineTokens('1. e4 { [%clk 0:02:59] } e5!? (1... c5 2. Nf3 (2. c3)) 2. Nf3 $1 Nc6 { [%clk 0:02:58.5] } *');
    expect(sans).toEqual(["e4", "e5", "Nf3", "Nc6"]);
    expect(clocks[0]).toBe(179);
    expect(clocks[3]).toBe(178.5);
  });

  it("accepts bare move lists, multi-game files and reports the first illegal move", () => {
    expect(parseFirstGame("1. d4 d5 2. c4").moves.map((m) => m.san)).toEqual(["d4", "d5", "c4"]);
    expect(splitGames(`${OPERA_GAME}\n\n${GAME_OF_THE_CENTURY}`)).toHaveLength(2);
    expect(() => parseGame("1. e4 e5 2. Ke3")).toThrow(/2\.Ke3 isn't legal/);
  });

  it("reads move lists written other ways: ½–½, e.p., 1…, ++, figurines, 0-0", () => {
    const sans = (pgn: string) => parseGame(pgn).moves.map((m) => m.san);
    expect(sans("1. e4 e5 2. Nf3 Nc6 ½-½")).toEqual(["e4", "e5", "Nf3", "Nc6"]);
    expect(sans("1. e4 e5 2. Nf3 Nc6 ½–½")).toHaveLength(4);
    expect(sans("1. d4 e5 2. dxe5 1… Nc6 2. Nf3 0–1")).toEqual(["d4", "e5", "dxe5", "Nc6", "Nf3"]);
    expect(sans("1. e4 d5 2. e5 f5 3. exf6 e.p. Nxf6")).toEqual(["e4", "d5", "e5", "f5", "exf6", "Nxf6"]);
    expect(sans("1. e4 e5 2. Qh5 Nc6 3. Bc4 Nf6 4. Qxf7++")).toEqual(["e4", "e5", "Qh5", "Nc6", "Bc4", "Nf6", "Qxf7#"]);
    expect(sans("1. e4 e5 2. ♘f3 ♞c6 3. ♗c4 ♗c5 4. 0-0")).toEqual(["e4", "e5", "Nf3", "Nc6", "Bc4", "Bc5", "O-O"]);
  });

  it("starts from a FEN header", () => {
    const g = parseGame('[SetUp "1"]\n[FEN "4k3/8/8/8/8/8/4P3/4K3 w - - 0 1"]\n\n1. e4 Kd7 *');
    expect(g.startFen).toBe("4k3/8/8/8/8/8/4P3/4K3 w - - 0 1");
    expect(g.moves).toHaveLength(2);
  });
});

describe("opening book", () => {
  it("knows common openings, recognises transpositions, and names them", () => {
    const g = parseGame("1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 *");
    expect(g.moves.every((m) => book.inBook(m.fenAfter))).toBe(true);
    expect(book.name(g.moves[4].fenAfter)?.name).toMatch(/Ruy Lopez/);
    expect(book.inBook(START_FEN)).toBe(false);
    expect(book.inBook(parseGame("1. a4 h5 2. Ra3 Rh6 3. Rg3 Rg6 *").moves[5].fenAfter)).toBe(false);
  });
});

describe("piece safety and sacrifices (no engine)", () => {
  it("evaluates exchanges with x-rays", () => {
    // Knight on e5 attacked by a pawn: losing.
    expect(see(placementFromFen("4k3/8/3p4/4N3/8/8/8/4K3 b - - 0 1"), "e5", "b")).toBe(3);
    // Rook takes a pawn defended by a pawn: bad for the taker.
    expect(see(placementFromFen("4k3/8/3p4/4p3/8/8/8/4RK2 w - - 0 1"), "e5", "w")).toBe(0);
    // Battery: two rooks against one defender win the pawn.
    expect(see(placementFromFen("4r1k1/8/8/4p3/8/8/4R3/4RK2 w - - 0 1"), "e5", "w")).toBe(1);
  });

  it("finds Morphy's 16.Qb8+ queen sacrifice and 10.Nxb5 knight sacrifice", () => {
    const qb8 = moveAt(OPERA_GAME, 31);
    expect(qb8.san).toBe("Qb8+");
    expect(detectSacrifice(qb8.fenBefore, qb8.uci)?.pieces.map((p) => p.type)).toEqual(["q"]);
    const nxb5 = moveAt(OPERA_GAME, 19);
    expect(nxb5.san).toBe("Nxb5");
    expect(detectSacrifice(nxb5.fenBefore, nxb5.uci)?.pieces.map((p) => p.square)).toEqual(["b5"]);
  });

  it("finds Fischer's 17...Be6, leaving the queen en prise", () => {
    const be6 = moveAt(GAME_OF_THE_CENTURY, 34);
    expect(be6.san).toBe("Be6");
    expect(detectSacrifice(be6.fenBefore, be6.uci)?.pieces.map((p) => p.type)).toContain("q");
  });

  it("doesn't call trades, rescues or quiet moves sacrifices", () => {
    // 4.dxe5 is a pawn trade.
    expect(detectSacrifice(moveAt(OPERA_GAME, 7).fenBefore, moveAt(OPERA_GAME, 7).uci)).toBeNull();
    // 1.e4 gives nothing away.
    expect(detectSacrifice(START_FEN, "e2e4")).toBeNull();
    // Moving an attacked knight to safety.
    expect(detectSacrifice("4k3/8/3p4/4N3/8/8/8/4K3 w - - 0 1", "e5f3")).toBeNull();
  });

  it("doesn't count a piece the opponent already declined to take as a new sacrifice", () => {
    const g = parseGame(KASPAROV_TOPALOV);
    const bb7 = g.moves[57];
    expect(bb7.san).toBe("Bb7");
    // After 28...Qxd5 the knight on f6 was already loose; 29.Ra7 declined it.
    const declined = unsafePieces(g.moves[56].fenBefore, "b");
    expect(declined.map((p) => p.square)).toContain("f6");
    expect(detectSacrifice(bb7.fenBefore, bb7.uci)?.pieces.map((p) => p.square)).toEqual(["f6"]);
    expect(detectSacrifice(bb7.fenBefore, bb7.uci, declined)).toBeNull();
  });

  it("counts a piece that can't be taken because of mate as offered", () => {
    // 16…Rxa3 (BLUNDER-MAN9999999 vs Ay7u, 2026-10-10; Chess.com: Brilliant): 17.bxa3 Bxa3#.
    const fen = "r4rk1/4bppp/1qn2n2/4pPB1/2Bp4/P7/1PPQ1PPP/2KR3R b - - 3 16";
    expect(detectSacrifice(fen, "a8a3")?.pieces.map((p) => p.type + p.square)).toEqual(["ra3"]);
  });

  it("lists unsafe pieces", () => {
    expect(unsafePieces("4k3/8/3p4/4N3/8/8/8/4K3 b - - 0 1", "w").map((p) => p.square)).toEqual(["e5"]);
  });
});

describe("classification rules (synthetic evaluations)", () => {
  const e4 = moveAt("1. e4", 1);
  const nf3 = moveAt("1. Nf3", 1);
  const base = { legalMoves: 20, inBook: false };

  it("labels by expected-score loss", () => {
    const c = (after: number, played = nf3) => classifyMove({ ...base, move: played, before: pa(cp(30), ["e2e4"]), after: pa(cp(after)) }).cls;
    expect(c(30, e4)).toBe("best");
    expect(c(20)).toBe("excellent");
    expect(c(-20)).toBe("good");
    expect(c(-60)).toBe("inaccuracy");
    expect(c(-150)).toBe("mistake");
    expect(c(-450)).toBe("blunder");
  });

  it("handles mates separately", () => {
    const mateW = (n: number): Evaluation => ({ kind: "mate", moves: n, winner: "w" });
    const mateB = (n: number): Evaluation => ({ kind: "mate", moves: n, winner: "b" });
    expect(classifyMove({ ...base, move: nf3, before: pa(mateW(3), ["e2e4"]), after: pa(mateW(3)) }).cls).toBe("excellent");
    expect(classifyMove({ ...base, move: nf3, before: pa(mateW(3), ["e2e4"]), after: pa(mateW(6)) }).cls).toBe("good");
    // A mate let go is a Mistake by the bands, and a Miss when the move gives nothing else away.
    expect(lossClass(mateW(3), cp(50), "w")).toBe("mistake");
    expect(classifyMove({ ...base, move: nf3, before: pa(mateW(3), ["e2e4"]), after: pa(cp(50)) }).cls).toBe("miss");
    expect(classifyMove({ ...base, move: nf3, before: pa(cp(20), ["e2e4"]), after: pa(mateB(1)) }).cls).toBe("blunder");
  });

  it("labels forced and book moves", () => {
    expect(classifyMove({ ...base, legalMoves: 1, move: nf3, before: pa(cp(0)), after: pa(cp(-300)) }).cls).toBe("forced");
    expect(classifyMove({ ...base, inBook: true, move: e4, before: pa(cp(30)), after: pa(cp(30)) }).cls).toBe("book");
  });

  it("calls a best move Great when every alternative is clearly worse", () => {
    const r = classifyMove({ ...base, move: e4, before: pa(cp(80), ["e2e4"], cp(-150)), after: pa(cp(80)) });
    expect(r.cls).toBe("great");
    // ...but not when you're winning anyway.
    expect(classifyMove({ ...base, move: e4, before: pa(cp(1200), ["e2e4"], cp(900)), after: pa(cp(1200)) }).cls).toBe("best");
  });

  it("calls a sacrifice Brilliant only when it is clearly better than not sacrificing", () => {
    // 30.Bxf8 (Hikaru vs demon64fields, 2026): takes a bishop and leaves the rook on a4 to the knight.
    const fen = "r1r2bk1/p2q1p1p/1p1P2pB/4Pp2/R7/P1n2N1P/3Q1PP1/R5K1 w - - 2 30";
    const move = parseGame(`[SetUp "1"]\n[FEN "${fen}"]\n\n30. Bxf8 *`).moves[0];
    const at = { ...base, move, legalMoves: 40 };
    expect(classifyMove({ ...at, before: pa(cp(430), ["h6f8"], cp(225)), after: pa(cp(430)) }).cls).toBe("brilliant");
    // The same sacrifice when a quiet move is just as good: not Brilliant (it isn't needed).
    expect(classifyMove({ ...at, before: pa(cp(80), ["h6f8"], cp(70)), after: pa(cp(80)) }).cls).not.toBe("brilliant");
  });

  it("measures a sacrifice against the best move that gives nothing away", () => {
    // 14.dxe6 (Ay7u vs jross0120, 2026-10-09; Chess.com: Brilliant): leaves the bishop on c4 to the
    // knight on a5, because 14…Nxc4 15.exf7+ wins the rook on e8. Depth-18 numbers: +0.32 against 14.Bb5's −0.06.
    const fen = "r2qr1k1/ppp2pbp/4p1p1/n2P4/2B5/2P1PQ1P/P4PP1/R1B2RK1 w - - 1 14";
    const move = parseGame(`[SetUp "1"]\n[FEN "${fen}"]\n\n14. dxe6 *`).moves[0];
    const at = { ...base, move, legalMoves: 42, after: pa(cp(29)) };
    const two = (second: string, ev: number): PositionAnalysis => ({
      eval: cp(32),
      depth: 18,
      lines: [
        { multipv: 1, depth: 18, eval: cp(32), pv: ["d5e6"] },
        { multipv: 2, depth: 18, eval: cp(ev), pv: [second] },
      ],
    });
    // 0.035 better than saving the bishop: Brilliant (a 0.04 margin used to lose it).
    expect(classifyMove({ ...at, before: two("c4b5", -6) }).cls).toBe("brilliant");
    // A quiet move just as good: the sacrifice isn't needed.
    expect(classifyMove({ ...at, before: two("c4b5", 30) }).cls).toBe("best");
    // The runner-up leaves the bishop hanging too (a3 is no better than a sacrifice), so it can't be
    // the yardstick: until the quiet move is searched the label stays conservative...
    const runnerUpSacrifices = two("a2a3", 31);
    expect(classifyMove({ ...at, before: runnerUpSacrifices }).cls).toBe("best");
    // ...and once it is, the sacrifice is measured against 14.Bb5.
    const quiet = { multipv: 1, depth: 18, eval: cp(-6), pv: ["c4b5"] };
    const withQuiet = classifyMove({ ...at, before: { ...runnerUpSacrifices, quiet } });
    expect(withQuiet.cls).toBe("brilliant");
    expect(withQuiet.quietLine?.pv[0]).toBe("c4b5");
  });

  it("judges 'already decided' on the players' own curve", () => {
    expect(decisiveSlope(null)).toBeCloseTo(0.00368208, 8);
    expect(decisiveSlope(1500) / decisiveSlope(null)).toBeCloseTo(0.73, 5);
    expect(decisiveSlope(2800) / decisiveSlope(null)).toBeCloseTo(0.865, 5);
    expect(decisiveSlope(3200)).toBeCloseTo(0.00368208, 8);
    expect(gameRating("1479", "1474")).toBe(1476.5);
    expect(gameRating("?", "2100")).toBe(2100);
    expect(gameRating()).toBeNull();
    // 16…Rxa3 at depth 18: −9.81, the runner-up 16…Bxa3 (a sacrifice too) −9.46, the best quiet move −8.16.
    const fen = "r4rk1/4bppp/1qn2n2/4pPB1/2Bp4/P7/1PPQ1PPP/2KR3R b - - 3 16";
    const move = parseGame(`[SetUp "1"]\n[FEN "${fen}"]\n\n16... Rxa3 *`).moves[0];
    const line = (ev: number, pv: string[], k = 1) => ({ multipv: k, depth: 18, eval: cp(ev), pv });
    const before: PositionAnalysis = { eval: cp(-981), depth: 18, lines: [line(-981, ["a8a3"]), line(-946, ["e7a3"], 2)], quiet: line(-816, ["f8b8"]) };
    const at = (rating?: number) => classifyMove({ ...base, move, legalMoves: 45, before, after: pa(cp(-1039)), rating }).cls;
    // For 1500-rated players −8 isn't yet a sure thing, so finding the sacrifice still counts...
    expect(at(1476)).toBe("brilliant");
    // ...while at 3100, or on Lichess's curve, the game was already decided without it.
    expect(at(3100)).toBe("best");
    expect(at()).toBe("best");
  });

  it("searches the best quiet move only where a sacrifice needs it", async () => {
    const pgn = `[SetUp "1"]\n[FEN "r2qr1k1/ppp2pbp/4p1p1/n2P4/2B5/2P1PQ1P/P4PP1/R1B2RK1 w - - 1 14"]\n\n14. dxe6 fxe6 *`;
    const g = parseGame(pgn);
    const line = (ev: number, pv: string[]) => ({ multipv: 1, depth: 18, eval: cp(ev), pv });
    const positions: PositionAnalysis[] = [
      { eval: cp(32), depth: 18, lines: [line(32, ["d5e6"]), { ...line(31, ["a2a3"]), multipv: 2 }] },
      { eval: cp(29), depth: 18, lines: [line(29, ["f7e6"]), { ...line(400, ["a5c4"]), multipv: 2 }] },
      { eval: cp(29), depth: 18, lines: [line(29, ["c4e2"])] },
    ];
    const review = classifyGame(g, positions, null);
    expect(review.moves[0].cls).toBe("best");
    expect(quietSearchPositions(g, review, positions)).toEqual([0]);
    const asked: string[][] = [];
    const fake = async (r: { searchmoves?: string[] }) => {
      asked.push(r.searchmoves ?? []);
      return [line(-6, ["c4b5", "c7c6"])];
    };
    return searchQuietMoves(g, positions, [0], [fake], { depth: 22 }).then((out) => {
      // Only moves that save (or guard) the bishop are quiet; 14.a3 and 14.dxe6 are not.
      expect(asked[0]).toContain("c4b5");
      expect(asked[0]).not.toContain("a2a3");
      expect(asked[0]).not.toContain("d5e6");
      expect(out[0]?.quiet?.pv[0]).toBe("c4b5");
      expect(classifyGame(g, out, null).moves[0].cls).toBe("brilliant");
    });
  });

  it("calls an unpunished opponent mistake a Miss", () => {
    const prev = { cls: "blunder", before: 0.55, move: { ply: 1 } } as unknown as ClassifiedMove;
    // We were at 45% before their blunder, the best reply would give 95%, we played something worth 50%.
    const r = classifyMove({ ...base, move: nf3, previous: prev, before: pa(cp(500), ["e2e4"]), after: pa(cp(10)) });
    expect(r.cls).toBe("miss");
    expect(r.missedPly).toBe(1);
  });

  describe("Miss: a chance let go, without giving anything away", () => {
    // White's rook can take the knight on d5, which nothing defends.
    const hanging = (moves: string) => parseGame(`[SetUp "1"]\n[FEN "2r1k3/8/8/3n4/8/8/8/3RK3 w - - 0 1"]\n\n${moves} *`).moves[0];
    const takeIt = pa(cp(0), ["d1d5", "c8c2", "e1d1"]);

    it("leaving a hanging piece is a Miss, whatever the opponent's last move was", () => {
      const r = classifyMove({ ...base, move: hanging("1. Ke2"), before: takeIt, after: pa(cp(-300), ["d5f4", "e2e3"]) });
      expect(r.cls).toBe("miss");
      expect(r.missed).toEqual({ kind: "material", material: 3 });
      expect(r.missedPly).toBeUndefined();
    });

    it("a move that loses material itself stays a Blunder", () => {
      // 1.Rc1?? leaves the knight and hangs the rook: 1…Rxc1+.
      const r = classifyMove({ ...base, move: hanging("1. Rc1"), before: takeIt, after: pa(cp(-800), ["c8c1", "e1d2"]) });
      expect(r.cls).toBe("blunder");
    });

    it("a move that allows mate stays a Blunder", () => {
      const r = classifyMove({ ...base, move: hanging("1. Ke2"), before: takeIt, after: pa({ kind: "mate", moves: 2, winner: "b" }, ["d5f4", "e2e3"]) });
      expect(r.cls).toBe("blunder");
    });

    it("letting a winning position go is a Miss", () => {
      const r = classifyMove({ ...base, move: nf3, before: pa(cp(500), ["e2e4"]), after: pa(cp(10)) });
      expect(r.cls).toBe("miss");
      expect(r.missed?.kind).toBe("win");
    });

    it("letting a forced mate go is a Miss", () => {
      const r = classifyMove({ ...base, move: nf3, before: pa({ kind: "mate", moves: 2, winner: "w" }, ["e2e4"]), after: pa(cp(150)) });
      expect(r.cls).toBe("miss");
      expect(r.missed?.kind).toBe("mate");
    });

    it("going from level to worse is the mover's own error, even right after the opponent's", () => {
      // They blundered from 90% to level; our move then drops to −3 with no chance missed.
      const prev = { cls: "blunder", before: 0.9, move: { ply: 1 } } as unknown as ClassifiedMove;
      const r = classifyMove({ ...base, move: nf3, previous: prev, before: pa(cp(0), ["e2e4"]), after: pa(cp(-300)) });
      expect(r.cls).toBe("blunder");
    });
  });

  it("computes Lichess-style accuracy", () => {
    expect(moveAccuracy(50, 50)).toBeCloseTo(100, 0);
    expect(moveAccuracy(80, 40)).toBeLessThan(25);
    expect(expectedScore(cp(0), "w")).toBeCloseTo(0.5);
  });
});

describe("game review with engine-free analysis", () => {
  it("classifies a whole game and computes accuracy", () => {
    const g = parseGame(SHILLING_TRAP);
    // Fake but consistent evals (White's view): 4.Nxe5 is dubious, 5.Nxf7?? walks into mate.
    const evals: Evaluation[] = [20, 30, 25, 30, 25, 40, -150, -160, -1500, -1500, -1500, -1600, -1600, -1700].map(cp);
    const positions: PositionAnalysis[] = evals.map((e, i) => pa(e, i < g.moves.length ? [g.moves[i].uci] : []));
    positions[6] = pa(cp(40), ["c3c3"]); // best before 4.Nxe5 was something else
    positions[8] = pa(cp(-160), ["e5g4"]); // best before 5.Nxf7 was Ng4
    positions.push(pa({ kind: "mate", moves: 0, winner: "b" }));
    const r = classifyGame(g, positions, book);
    expect(r.moves.slice(0, 4).every((m) => m.cls === "book")).toBe(true);
    expect(r.moves[8].move.san).toBe("Nxf7");
    expect(r.moves[8].cls).toBe("blunder");
    expect(r.moves[13].cls).toBe("best"); // mate
    const acc = gameAccuracy(r.moves);
    expect(acc.w!).toBeGreaterThan(0);
    expect(acc.w!).toBeLessThan(acc.b!);
  });
});

describe("two-pass review", () => {
  it("re-searches only the positions around tactical labels, deeper", async () => {
    const g = parseGame(SHILLING_TRAP);
    const calls: { fen: string; depth: number }[] = [];
    // A fake engine: level until White's 5.Nxf7, then Black is winning.
    const fake = async (r: { fen: string; depth: number }) => {
      calls.push(r);
      const i = [g.startFen, ...g.moves.map((m) => m.fenAfter)].indexOf(r.fen);
      const e = i >= 9 ? cp(-900) : cp(20);
      return [{ multipv: 1, depth: r.depth, eval: e, pv: [] }];
    };
    const first = await analysePositions(g, [fake, fake], { depth: 10 });
    expect(calls).toHaveLength(14); // 15 positions; the final mate needs no search
    const review = classifyGame(g, first, book);
    expect(review.moves[8].cls).toBe("blunder"); // 5.Nxf7??
    const crit = criticalPositions(review, first, 14);
    expect(crit).toEqual([8, 9]);
    calls.length = 0;
    const second = await analysePositions(g, [fake], { depth: 14, indices: crit, existing: first });
    expect(calls.map((c) => c.depth)).toEqual([14, 14]);
    expect(second[8]!.depth).toBe(14);
    expect(second[3]).toBe(first[3]);
  });
});

describe("single-queue review", () => {
  const g = parseGame(SHILLING_TRAP);
  const fens = [g.startFen, ...g.moves.map((m) => m.fenAfter)];
  const at = (fen: string) => fens.indexOf(fen);
  // Level until White's 5.Nxf7, then Black is winning (as in the two-pass test).
  const lineFor = (r: { fen: string; depth: number }) => [{ multipv: 1, depth: r.depth, eval: at(r.fen) >= 9 ? cp(-900) : cp(20), pv: [] }];
  const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

  it("double-checks the same positions as the two passes did", async () => {
    const calls: { i: number; depth: number }[] = [];
    const fake = async (r: { fen: string; depth: number }) => {
      calls.push({ i: at(r.fen), depth: r.depth });
      return lineFor(r);
    };
    const out = await runReview(g, [fake, fake], { depth: 10, verifyDepth: 14, book: Promise.resolve(book) });
    expect(calls.filter((c) => c.depth === 10)).toHaveLength(14);
    expect(calls.filter((c) => c.depth === 14).map((c) => c.i).sort((a, b) => a - b)).toEqual([8, 9]);
    expect(out[8]!.depth).toBe(14);
    expect(out[3]!.depth).toBe(10);
    expect(classifyGame(g, out, book).moves[8].cls).toBe("blunder");
  });

  it("starts the deeper checks while a slow last position is still being searched, slowest first", async () => {
    const log: string[] = [];
    // The last position to search is held until a deeper check has started (no race with the
    // runner's speed); of the two positions to double-check, 9 took far longer than 8 (by a
    // margin no busy runner can blur: times are measured on one thread shared with the labelling).
    let release!: () => void;
    const gate = new Promise<void>((r) => (release = r));
    const fake = async (r: { fen: string; depth: number }) => {
      const i = at(r.fen);
      log.push(`start ${i}@${r.depth}`);
      if (r.depth === 10 && i === 13) await gate;
      else if (r.depth === 10 && i === 9) await delay(1000);
      log.push(`end ${i}@${r.depth}`);
      return lineFor(r);
    };
    const progress: number[] = [];
    const run = runReview(g, [fake, fake], { depth: 10, verifyDepth: 14, book: Promise.resolve(book), onProgress: (p) => progress.push(p.analysed) });
    for (let t = 0; t < 200 && !log.some((l) => l.endsWith("@14")); t++) await delay(50);
    release();
    await run;
    expect(log.indexOf("start 9@14")).toBeGreaterThan(-1);
    expect(log.indexOf("start 9@14")).toBeLessThan(log.indexOf("end 13@10"));
    expect(log.indexOf("start 9@14")).toBeLessThan(log.indexOf("start 8@14"));
    expect(Math.max(...progress)).toBe(15);
  }, 20_000);

  it("waits for the opening book before choosing what to double-check", async () => {
    let release!: (b: typeof book) => void;
    const later = new Promise<typeof book>((r) => (release = r));
    const depths: number[] = [];
    const fake = async (r: { fen: string; depth: number }) => {
      depths.push(r.depth);
      return lineFor(r);
    };
    const run = runReview(g, [fake], { depth: 10, verifyDepth: 14, book: later });
    await delay(20);
    expect(depths.every((d) => d === 10)).toBe(true);
    release(book);
    await run;
    expect(depths.filter((d) => d === 14)).toHaveLength(2);
  });

  it("hands a failed engine's work to the others", async () => {
    let broken = true;
    const flaky = async (r: { fen: string; depth: number }) => {
      if (broken) {
        broken = false;
        throw new Error("worker died");
      }
      return lineFor(r);
    };
    const ok = async (r: { fen: string; depth: number }) => lineFor(r);
    const out = await runReview(g, [flaky, ok], { depth: 10, verifyDepth: 14, book: Promise.resolve(book) });
    expect(out.filter(Boolean)).toHaveLength(15);
    await expect(runReview(g, [async () => Promise.reject(new Error("no engine"))], { depth: 10, verifyDepth: 14, book: Promise.resolve(book) })).rejects.toThrow("no engine");
  });
});

describe("accuracy on Chess.com's scale", () => {
  it("maps perfect play to 100 and keeps the order of better and worse games", async () => {
    const { gameAccuracy: acc, moveAccuracyFor } = await import("./accuracy");
    expect(moveAccuracyFor(60, 60)).toBeCloseTo(100, 0);
    const mk = (before: number, after: number, color: "w" | "b" = "w") => ({ move: { color }, before, after, cls: "best" }) as unknown as ClassifiedMove;
    const perfect = acc([mk(0.6, 0.6), mk(0.5, 0.5)]);
    expect(perfect.w).toBe(100);
    const sloppy = acc([mk(0.6, 0.55), mk(0.55, 0.45), mk(0.5, 0.2)]);
    expect(sloppy.w!).toBeLessThan(80);
    expect(sloppy.w!).toBeGreaterThanOrEqual(0);
    expect(perfect.b).toBeNull();
  });
});
