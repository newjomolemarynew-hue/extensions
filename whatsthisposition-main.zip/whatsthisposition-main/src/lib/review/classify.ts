/**
 * Move classification for game review, in the style of Chess.com's Game Review.
 *
 * Every move is judged by how much of the mover's expected score (win chance)
 * it gives up compared with the engine's best move:
 *   Best (top move) · Excellent < 2% · Good < 5% · Inaccuracy < 10% · Mistake < 20% · Blunder ≥ 20%
 * with mate-aware rules, plus the special labels:
 *   Book       the position after the move is opening theory (while the game is still in book)
 *   Forced     the only legal move
 *   Great      the best move when every alternative is clearly worse (≥ 10% loss)
 *   Brilliant  the best move, it really gives material away (see safety.ts), and it beats the best
 *              move that gives nothing away (SACRIFICE_MARGIN; see quietAlternative)
 *   Miss       an error that only lets a chance go (a mate, material, a winning position) without
 *              giving anything away itself (see missedChance)
 *
 * Expected score uses Lichess's win% curve. Thresholds match Chess.com's published
 * expected-points bands; Great/Brilliant gating follows WintrChess's ideas.
 */
import { Chess } from "chess.js";
import { other, type Color } from "../chess/types";
import type { EngineLine } from "../engine/client";
import { evalFor, type Evaluation } from "../engine/score";
import { detectSacrifice, unsafePieces, wasFreeMaterial, type SacrificeInfo } from "./safety";
import type { MasterMove } from "./masters";
import type { GameMove } from "./pgn";

export type MoveClass =
  | "brilliant"
  | "great"
  | "best"
  | "excellent"
  | "good"
  | "book"
  | "inaccuracy"
  | "mistake"
  | "miss"
  | "blunder"
  | "forced";

export const CLASS_ORDER: MoveClass[] = ["brilliant", "great", "best", "excellent", "good", "book", "inaccuracy", "mistake", "miss", "blunder", "forced"];

export const CLASS_INFO: Record<MoveClass, { label: string; symbol: string; color: string }> = {
  brilliant: { label: "Brilliant", symbol: "!!", color: "#1fc0a8" },
  great: { label: "Great", symbol: "!", color: "#5b8fd6" },
  best: { label: "Best", symbol: "★", color: "#86b93f" },
  excellent: { label: "Excellent", symbol: "👍", color: "#9cc24a" },
  good: { label: "Good", symbol: "✓", color: "#86a96a" },
  book: { label: "Book", symbol: "📖", color: "#b08d64" },
  inaccuracy: { label: "Inaccuracy", symbol: "?!", color: "#f2c13a" },
  mistake: { label: "Mistake", symbol: "?", color: "#ef8f2f" },
  miss: { label: "Miss", symbol: "✕", color: "#e86a6a" },
  blunder: { label: "Blunder", symbol: "??", color: "#e0362f" },
  forced: { label: "Forced", symbol: "→", color: "#9aa3ad" },
};

/**
 * How much better (expected score) a sacrifice must be than the best move that gives nothing away
 * to be Brilliant: about the engine's noise, so only liquidations that a quiet move matches
 * (a piece handed back into a dead-equal ending) are left out. Chess.com's and WintrChess's
 * definitions have no margin at all; an earlier 0.04 against the second-best line lost real
 * sacrifices in level positions (0.04 is about 40 centipawns there) and whenever the
 * second-best move was itself a sacrifice.
 */
export const SACRIFICE_MARGIN = 0.01;

/** Chess annotation marks, for writing a move as e.g. "16.Qb8+!!". */
export const ANNOTATION: Partial<Record<MoveClass, string>> = { brilliant: "!!", great: "!", inaccuracy: "?!", mistake: "?", miss: "?", blunder: "??" };

/** Lichess's win-chance curve, as a 0–1 expected score for `color`. */
export function expectedScore(e: Evaluation, color: Color): number {
  return expectedScoreAt(e, color, LICHESS_SLOPE);
}

const LICHESS_SLOPE = 0.00368208;

/**
 * How steeply an evaluation turns into a result for players of this rating (the slope of the
 * win-chance curve). Fitted on 42,000 positions from evenly matched Chess.com games
 * (scripts/eval/fit-winprob.py, 2026-10-10): players below about 2600 convert an advantage like a
 * curve 0.73 times as steep as Lichess's (which matches the 3000-level blitz games), so +7 is not
 * yet "completely winning" for them; the factor rises to 1 at 3000. Without a rating: Lichess's.
 */
export function decisiveSlope(rating?: number | null): number {
  if (!rating) return LICHESS_SLOPE;
  const f = rating <= 2600 ? 0.73 : rating >= 3000 ? 1 : 0.73 + ((rating - 2600) / 400) * 0.27;
  return LICHESS_SLOPE * f;
}

/** The win-chance curve with a given slope, as a 0–1 expected score for `color`. */
export function expectedScoreAt(e: Evaluation, color: Color, slope: number): number {
  if (e.kind === "mate") return e.winner === color ? 1 : 0;
  const cp = color === "w" ? e.cp : -e.cp;
  return 1 / (1 + Math.exp(-slope * cp));
}

export interface PositionAnalysis {
  /** Engine lines for the position (best first). Empty for game-over positions. */
  lines: EngineLine[];
  /** Eval to use for the position (best line, or the game-over result). */
  eval: Evaluation;
  depth: number;
  /**
   * The best move that gives no material away, searched only when the top two lines are both
   * sacrifices (`quietSearchPositions`): what a sacrifice is measured against for Brilliant.
   */
  quiet?: EngineLine;
}

export interface ClassifiedMove {
  move: GameMove;
  cls: MoveClass;
  /** Expected-score loss for the mover, 0–1. */
  loss: number;
  /** Mover's expected score before (best play) and after the move, 0–1. */
  before: number;
  after: number;
  /** Lichess move accuracy, 0–100. */
  accuracy: number;
  bestUci: string | null;
  bestSan: string | null;
  bestLine: EngineLine | null;
  secondLine: EngineLine | null;
  /** The game line after the move, from the engine (opponent to move). */
  replyLine: EngineLine | null;
  evalBefore: Evaluation;
  evalAfter: Evaluation;
  sacrifice: SacrificeInfo | null;
  /** For a sacrifice the engine plays: the best move that gives nothing away, which it was measured against. */
  quietLine?: EngineLine | null;
  /** For Miss: what was let go (see `missedChance`), and how much more material the best line would have won. */
  missed?: { kind: MissKind; material?: number };
  /** For Miss right after the opponent's error: that error, which went unpunished. */
  missedPly?: number;
  opening?: { eco: string; name: string } | null;
  /** What masters played in the position before the move: set on book moves and on the move that left the book. */
  theory?: TheoryInfo | null;
}

/** A master choice in a position, with the line masters most often follow after it. */
export interface TheoryOption extends MasterMove {
  san: string;
  /** UCI moves after it, following the most played move each time. */
  line: string[];
}

export interface TheoryInfo {
  /** Master games that reached the position before the move. */
  games: number;
  /** This move's master statistics (null when masters didn't play it as theory). */
  played: MasterMove | null;
  /** Master moves here, most played first. */
  options: TheoryOption[];
}

/** Evaluation of a game-over position (mate or draw), White-relative. */
export function terminalEval(fen: string): Evaluation | null {
  const c = new Chess(fen);
  if (c.isCheckmate()) return { kind: "mate", moves: 0, winner: c.turn() === "w" ? "b" : "w" };
  if (c.isDraw() || c.isStalemate()) return { kind: "cp", cp: 0 };
  return null;
}

/** Lichess move accuracy from win% before/after (mover's view, 0–100). */
export function moveAccuracy(winBefore: number, winAfter: number): number {
  const a = 103.1668 * Math.exp(-0.04354 * Math.max(0, winBefore - winAfter)) - 3.1669;
  return Math.max(0, Math.min(100, a));
}

function pointLossClass(prev: Evaluation, cur: Evaluation, mover: Color, loss: number): MoveClass {
  const curMover = evalFor(cur, mover);
  // Mate → mate
  if (prev.kind === "mate" && cur.kind === "mate") {
    const hadMate = prev.winner === mover;
    const hasMate = cur.winner === mover;
    if (hadMate && !hasMate) return cur.moves <= 3 ? "blunder" : "mistake";
    if (!hadMate) return "best"; // being mated either way: delaying it is all you can do
    const delay = cur.moves - (prev.moves - 1);
    if (delay <= 0) return "best";
    if (delay < 2) return "excellent";
    if (delay < 7) return "good";
    return "inaccuracy";
  }
  // Mate → centipawns: a forced mate was let go
  if (prev.kind === "mate" && cur.kind === "cp") {
    if (prev.winner !== mover) return "best"; // escaping a mate threat
    if (curMover >= 800) return "excellent";
    if (curMover >= 400) return "good";
    if (curMover >= 200) return "inaccuracy";
    if (curMover >= 0) return "mistake";
    return "blunder";
  }
  // Centipawns → mate
  if (prev.kind === "cp" && cur.kind === "mate") {
    if (cur.winner === mover) return "best";
    if (cur.moves <= 2) return "blunder";
    if (cur.moves <= 5) return "mistake";
    return "inaccuracy";
  }
  if (loss < 0.005) return "best";
  if (loss < 0.02) return "excellent";
  if (loss < 0.05) return "good";
  if (loss < 0.1) return "inaccuracy";
  if (loss < 0.2) return "mistake";
  return "blunder";
}

const RANK: Record<MoveClass, number> = {
  brilliant: 9,
  great: 8,
  best: 7,
  excellent: 6,
  good: 5,
  book: 6,
  forced: 7,
  inaccuracy: 3,
  mistake: 2,
  miss: 2,
  blunder: 1,
};

/** Class from the evaluation alone (best line vs played line), mover's view. */
export function lossClass(best: Evaluation, played: Evaluation, mover: Color): MoveClass {
  return pointLossClass(best, played, mover, Math.max(0, expectedScore(best, mover) - expectedScore(played, mover)));
}

export const isBad = (c: MoveClass) => c === "inaccuracy" || c === "mistake" || c === "blunder" || c === "miss";
export const classRank = (c: MoveClass) => RANK[c];

export interface ClassifyInput {
  move: GameMove;
  before: PositionAnalysis;
  after: PositionAnalysis;
  legalMoves: number;
  inBook: boolean;
  /** The previous move (the opponent's), already classified. */
  previous?: ClassifiedMove;
  opening?: { eco: string; name: string } | null;
  theory?: TheoryInfo | null;
  /** The players' rating (their average when both are known): how decided a position is depends on it. */
  rating?: number | null;
}

/** The players' rating for `decisiveSlope`: the average of the two when both are known. */
export function gameRating(whiteElo?: string, blackElo?: string): number | null {
  const r = [whiteElo, blackElo].map(Number).filter((x) => Number.isFinite(x) && x > 0);
  return r.length ? r.reduce((a, b) => a + b, 0) / r.length : null;
}

/** Classifies one move. Pure: everything comes from the two position analyses. */
export function classifyMove(inp: ClassifyInput): ClassifiedMove {
  const { move, before, after } = inp;
  const mover = move.color;
  const best = before.lines[0] ?? null;
  const second = before.lines[1] ?? null;
  const evalBefore = before.eval;
  const evalAfter = after.eval;
  const epBefore = expectedScore(evalBefore, mover);
  const epAfter = expectedScore(evalAfter, mover);
  const loss = Math.max(0, epBefore - epAfter);
  const accuracy = moveAccuracy(epBefore * 100, epAfter * 100);
  const bestUci = best?.pv[0] ?? null;
  let bestSan: string | null = null;
  if (bestUci) {
    try {
      bestSan = new Chess(move.fenBefore).move({ from: bestUci.slice(0, 2), to: bestUci.slice(2, 4), promotion: bestUci[4] }).san;
    } catch {
      bestSan = null;
    }
  }
  const base = {
    move,
    loss,
    before: epBefore,
    after: epAfter,
    accuracy,
    bestUci,
    bestSan,
    bestLine: best,
    secondLine: second,
    replyLine: after.lines[0] ?? null,
    evalBefore,
    evalAfter,
    sacrifice: null as SacrificeInfo | null,
    opening: inp.opening ?? null,
    theory: inp.theory ?? null,
  };

  if (inp.legalMoves <= 1) return { ...base, cls: "forced" };
  if (inp.inBook) return { ...base, cls: "book" };
  if (move.isMate) return { ...base, cls: "best" };

  const topPlayed = bestUci === move.uci;
  let cls: MoveClass = topPlayed ? "best" : pointLossClass(evalBefore, evalAfter, mover, loss);

  // Great / Brilliant candidates: not easy, not forced, not already decided. "Decided" is judged on
  // the players' own curve: the same +7 that wins for a 3000 player is still a game below 2600.
  const secondEp = second ? expectedScore(second.eval, mover) : null;
  const slope = decisiveSlope(inp.rating);
  const decided = (e: Evaluation) => expectedScoreAt(e, mover, slope) >= 0.93;
  const inCheckBefore = new Chess(move.fenBefore).inCheck();
  const open = expectedScoreAt(evalAfter, mover, slope) >= 0.45 && !inCheckBefore && move.promotion !== "q";
  const candidate = open && !(second ? decided(second.eval) : decided(evalAfter));
  const nearBest = topPlayed || loss < 0.02;

  if (candidate && topPlayed && !(evalAfter.kind === "mate" && evalAfter.winner === mover)) {
    const capturedFree = move.captured ? wasFreeMaterial(move.fenBefore, captureSquare(move)) : false;
    if (!capturedFree && secondEp !== null && epBefore - secondEp >= 0.1) cls = "great";
  }

  const prev = inp.previous;
  let sacrifice: SacrificeInfo | null = null;
  let quietLine: EngineLine | null = null;
  if (open && nearBest) {
    // Pieces the opponent could already take on their last turn were offered (and declined) before this move.
    const declined = prev ? unsafePieces(prev.move.fenBefore, mover) : [];
    sacrifice = detectSacrifice(move.fenBefore, move.uci, declined);
    // Brilliant: the sacrifice is the engine's choice and better than playing it safe (a liquidation
    // that a quiet move matches, e.g. into a dead draw, isn't brilliant), and without sacrificing the
    // game wouldn't already be decided. Both are measured against the best quiet move: a runner-up
    // that sacrifices too is another way of finding the idea, not a way of doing without it.
    if (sacrifice?.pieces.length && topPlayed) {
      quietLine = quietAlternative(move.fenBefore, move.uci, before, declined);
      const needed = !quietLine || epBefore - expectedScore(quietLine.eval, mover) >= SACRIFICE_MARGIN;
      const decidedWithout = quietLine ? decided(quietLine.eval) : decided(evalAfter);
      if (needed && !decidedWithout) cls = "brilliant";
    }
  }

  // Miss: an error whose cost is a chance let go, not damage done (missedChance).
  const missed = !topPlayed ? missedChance(move, before, after, cls, slope, prev) : null;
  if (missed) return { ...base, cls: "miss", missed, ...(prev && isError(prev.cls) ? { missedPly: prev.move.ply } : {}), sacrifice, quietLine };

  return { ...base, cls, sacrifice, quietLine };
}

export type MissKind = "mate" | "material" | "win" | "error";

/**
 * Winning chances on the players' own curve (`decisiveSlope`) that count as "winning" for Miss
 * (about +3 for club players, +2.3 at the top) and as "ahead" after the opponent's error (about
 * +1.5 and +1.1). Chosen by reading every error in 119 of Ay7u's games (2026-10-25).
 */
const WINNING = 0.7;
const AHEAD = 0.6;

const isError = (c: MoveClass) => c === "mistake" || c === "blunder" || c === "miss";

/**
 * What an error let go, when that is all it did: Chess.com's Miss ("fails to take advantage of a
 * tactical opportunity, find mate, or punish an opponent's bad move"), next to its Blunder, which
 * "must lose material or allow checkmate". There was a chance:
 *   mate      the best line mates, and the move doesn't;
 *   material  the best line wins material, at least two points more than the game's line;
 *   win       the mover was winning, and isn't after the move;
 *   error     the opponent's last move was a Mistake, Blunder or Miss that put the mover ahead, and
 *             the move hands it back, though no lower than before that error;
 * and the move gives nothing away itself: it doesn't allow mate or lose two points of material or
 * more along the engine's line (nor, for the last two, leave the mover lost). A slip in the
 * Inaccuracy band only counts when it costs a tenth of the winning chances on the players' own curve.
 */
export function missedChance(move: GameMove, before: PositionAnalysis, after: PositionAnalysis, cls: MoveClass, slope: number, prev?: ClassifiedMove): ClassifiedMove["missed"] | null {
  if (cls !== "inaccuracy" && cls !== "mistake" && cls !== "blunder") return null;
  const mover = move.color;
  const mates = (e: Evaluation, c: Color) => e.kind === "mate" && e.winner === c;
  if (mates(after.eval, other(mover))) return null;
  const was = expectedScoreAt(before.eval, mover, slope);
  const now = expectedScoreAt(after.eval, mover, slope);
  if (cls === "inaccuracy" && was - now < 0.1) return null;
  const kept = lineMaterial(move.fenBefore, [move.uci, ...(after.lines[0]?.pv ?? [])], mover);
  if (kept <= -2) return null;
  if (mates(before.eval, mover) && !mates(after.eval, mover)) return { kind: "mate" };
  const won = before.lines[0] ? lineMaterial(move.fenBefore, before.lines[0].pv, mover) : 0;
  if (won >= 2 && won - kept >= 2) return { kind: "material", material: won - kept };
  // From winning (or ahead) to lost with no material gone along the line is damage the line doesn't
  // show yet (a mating attack, a piece that can't escape): the move's own error, not a chance let go.
  if (now < 1 - WINNING) return null;
  if (was >= WINNING && now < WINNING && was - now >= 0.1) return { kind: "win" };
  // Where the mover stood before the opponent's error, on the same (Lichess) curve as prev.before.
  if (prev && isError(prev.cls) && was >= AHEAD && expectedScore(after.eval, mover) >= 1 - prev.before - 0.05) return { kind: "error" };
  return null;
}

/**
 * The line a sacrifice (`uci`) is measured against: the best move that gives no material away.
 * That is the second-best line when it is quiet, the searched `quiet` line when the second-best
 * is a sacrifice too, and (until that search has run) the second-best line itself, which can
 * only understate the margin. Null when there is no other move to compare with.
 */
export function quietAlternative(fen: string, uci: string, before: PositionAnalysis, declined: ReturnType<typeof unsafePieces> = []): EngineLine | null {
  const second = before.lines.find((l) => l.pv[0] && l.pv[0] !== uci) ?? null;
  if (!second) return before.quiet ?? null;
  if (!detectSacrifice(fen, second.pv[0], declined)?.pieces.length) return second;
  return before.quiet ?? second;
}

/** True when the second-best line is a sacrifice too, so the margin needs the `quiet` search. */
export function needsQuietSearch(fen: string, uci: string, before: PositionAnalysis, declined: ReturnType<typeof unsafePieces> = []): boolean {
  const second = before.lines.find((l) => l.pv[0] && l.pv[0] !== uci);
  return !!second && !before.quiet && !!detectSacrifice(fen, second.pv[0], declined)?.pieces.length;
}

const POINTS: Record<string, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

/**
 * Material `mover` comes out with along an engine line from `fen`, against the material now:
 * counted at the last point within `maxPlies` where the captures have settled (a move that takes
 * nothing, answered by one that takes nothing), so a piece taken and retaken counts as a trade,
 * not a win. The end of the line stands in when it never settles.
 */
export function lineMaterial(fen: string, pv: string[], mover: Color, maxPlies = 10): number {
  const c = new Chess(fen);
  const count = () => {
    let d = 0;
    for (const row of c.board()) for (const p of row) if (p) d += (p.color === mover ? 1 : -1) * POINTS[p.type];
    return d;
  };
  const start = count();
  const after: number[] = [];
  const took: boolean[] = [];
  for (const uci of pv.slice(0, maxPlies)) {
    try {
      const m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
      took.push(!!m.captured);
    } catch {
      break;
    }
    after.push(count() - start);
  }
  for (let k = after.length - 1; k >= 0; k--) if (!took[k] && (k + 1 >= took.length || !took[k + 1])) return after[k];
  return after.length ? after[after.length - 1] : 0;
}

interface LineLike {
  pv: string[];
  eval: Evaluation;
  depth: number;
}

/**
 * Labels one candidate move in a single position (no game around it), with the
 * same rules as game review. `played` is the engine's line starting with the move,
 * `best`/`second` the top two lines of the position.
 */
export function classifyCandidate(fen: string, played: LineLike, best: LineLike, second?: LineLike | null): ClassifiedMove | null {
  const chess = new Chess(fen);
  const uci = played.pv[0];
  if (!uci) return null;
  let m;
  try {
    m = chess.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
  } catch {
    return null;
  }
  const move: GameMove = {
    ply: 1,
    san: m.san,
    uci: m.lan,
    from: m.from,
    to: m.to,
    color: m.color,
    piece: m.piece,
    captured: m.captured,
    promotion: m.promotion,
    fenBefore: fen,
    fenAfter: m.after,
    moveNumber: Number(fen.split(" ")[5]) || 1,
    isCheck: m.san.includes("+") || m.san.includes("#"),
    isMate: m.san.includes("#"),
  };
  const asLine = (l: LineLike, k: number): EngineLine => ({ multipv: k, depth: l.depth, eval: l.eval, pv: l.pv });
  const lines = [asLine(best, 1), ...(second ? [asLine(second, 2)] : [])];
  return classifyMove({
    move,
    before: { lines, eval: best.eval, depth: best.depth },
    after: { lines: played.pv.length > 1 ? [asLine({ ...played, pv: played.pv.slice(1) }, 1)] : [], eval: played.eval, depth: played.depth },
    legalMoves: new Chess(fen).moves().length,
    inBook: false,
  });
}

function captureSquare(m: GameMove) {
  if (m.piece === "p" && m.captured && m.from[0] !== m.to[0]) {
    const p = new Chess(m.fenBefore).get(m.to);
    if (!p) return `${m.to[0]}${m.from[1]}` as GameMove["to"]; // en passant
  }
  return m.to;
}
