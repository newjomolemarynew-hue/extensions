import Link from "next/link";
import { LANDING } from "@/lib/landing";
import { CLASS_INFO, CLASS_ORDER, type MoveClass } from "@/lib/review/classify";
import { ClassIcon } from "../review/ClassIcon";

/** The rule behind every label, exactly as src/lib/review/classify.ts applies it. */
const RULES: Record<MoveClass, string> = {
  brilliant: "The engine's best move, and it really gives material away: checked with exchange maths on the board, not guessed from the score, and clearly better than not sacrificing.",
  great: "The only good move: every alternative throws away at least 10% of your winning chances.",
  best: "The engine's top choice in the position.",
  excellent: "Not the top move, but it costs under 2% of your winning chances.",
  good: "Costs between 2% and 5% of your winning chances.",
  book: "Opening theory: a move strong players really choose here, from 1.8 million of their games.",
  inaccuracy: "Gives away 5–10% of your winning chances.",
  mistake: "Gives away 10–20% of your winning chances.",
  miss: "You had a mate, a way to win material or a winning position, and let it go without losing anything yourself.",
  blunder: "Gives away 20% or more, or walks into a forced mate.",
  forced: "The only legal move.",
};

/**
 * The label legend. On the page that explains the labels (`page`) it carries that page's heading;
 * elsewhere it links there.
 */
export function Labels({ page = false }: { page?: boolean }) {
  return (
    <section className="section">
      <div className="section-head">
        {page ? (
          <>
            <h1 className="h-section">{LANDING.labels.h1}</h1>
            <p className="section-lede">{LANDING.labels.lede}</p>
          </>
        ) : (
          <>
            <h2 className="h-section">Every move gets a label</h2>
            <p className="section-lede">
              Each move is compared with Stockfish&apos;s best in winning chances, on Lichess&apos;s win-probability curve. The same rules apply to every game, from your
              blitz games to world championships. <Link href={LANDING.labels.path}>How each label is decided</Link>
            </p>
          </>
        )}
      </div>
      <ul className="legend">
        {CLASS_ORDER.map((c) => (
          <li key={c} style={{ ["--cls" as string]: CLASS_INFO[c].color }}>
            <ClassIcon cls={c} size={28} />
            <b>{CLASS_INFO[c].label}</b>
            <span>{RULES[c]}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
