"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { PeekOrientation } from "../peek/Peek";
import { EngineLines } from "../EngineLines";
import { PlayBoard } from "../PlayBoard";
import { useLiveLines } from "../useLiveLines";
import { placementFromFen } from "@/lib/chess/fen";
import { other, type Color, type Square } from "@/lib/chess/types";
import type { EngineLine } from "@/lib/engine/client";
import type { Evaluation } from "@/lib/engine/score";
import { buildCommentary } from "@/lib/commentary";
import { computeFacts, marksForLenses, type Fact, type LensId, type Marks } from "@/lib/facts";
import { threatFact } from "@/lib/facts/engineFacts";
import { explainWhyNot } from "@/lib/facts/explain";
import { boardIdeas } from "@/lib/reason/ideas";
import { buildLedger, polarityOf } from "@/lib/facts/ledger";
import { findPlans } from "@/lib/facts/plans";
import { planCard, type PlanCard } from "@/lib/plans/cards";
import type { TimedPlan } from "@/lib/plans/timing";
import { buildTour, type Scene } from "@/lib/facts/tour";
import { deepScenes } from "@/lib/deep/scenes";
import { traceSquare } from "@/lib/facts/trace";
import { emptyMarks } from "@/lib/facts/types";
import { buildVariation, fenAtPly, moveAtPly, navigate, type NavAction } from "@/lib/variation";
import { Caption, EvalBar, sideName, type CaptionData } from "./bits";
import { ComparePanel } from "./ComparePanel";
import { LayersPanel } from "./LayersPanel";
import { LinesPanel, type LineRef, type WhyState } from "./LinesPanel";
import { OverviewPanel, type Shown } from "./OverviewPanel";
import { StrategyPanel } from "./StrategyPanel";
import { usePlanTimings } from "./usePlanTimings";
import { QuizPanel } from "./QuizPanel";
import { ScanIntro } from "./ScanIntro";
import { Scoreboard } from "./Scoreboard";
import { StoryPanel } from "./StoryPanel";
import { SEARCH_PRESETS, useAnalysis } from "./useAnalysis";
import { VariationBar } from "./VariationBar";

type Tab = "overview" | "plans" | "story" | "moves" | "layers";
type MovesMode = "lines" | "compare" | "quiz";

interface Props {
  fen: string;
  orientation: Color;
  onOrientation: (c: Color) => void;
  onEdit: () => void;
}

const THREAT_KINDS = ["hanging", "attacked-by-cheaper", "engine-threat", "check", "fork", "skewer", "pin-absolute", "back-rank"];

const factCaption = (f: Fact, label?: string): CaptionData => {
  const pol = polarityOf(f);
  return {
    key: f.id,
    tone: pol === "strength" ? "opportunity" : pol === "weakness" ? "danger" : f.tone,
    tag: pol === "strength" ? "+" : pol === "weakness" ? "−" : "•",
    kind: `${sideName(f.side)} · ${label ?? (pol === "neutral" ? "note" : pol)}`,
    text: f.title,
  };
};

export function AnalysisView({ fen, orientation, onOrientation, onEdit }: Props) {
  const [presetIdx, setPresetIdx] = useState(1);
  const [multipv, setMultipv] = useState(3);
  const settings = SEARCH_PRESETS[presetIdx];
  const a = useAnalysis(fen, settings, multipv);

  const [introDone, setIntroDone] = useState(false);
  const [tab, setTab] = useState<Tab>("overview");
  const [movesMode, setMovesMode] = useState<MovesMode>("lines");
  const [lenses, setLenses] = useState<LensId[]>(["threats"]);
  const [savedLenses, setSavedLenses] = useState<LensId[]>(["threats"]);
  const [focus, setFocus] = useState<string | null>(null);
  const [hoverFact, setHoverFact] = useState<Fact | null>(null);
  // What a remark or a plan shows on the board: hovered, or tapped so it stays.
  const [shownHover, setShownHover] = useState<Shown | null>(null);
  const [shownPin, setShownPin] = useState<Shown | null>(null);
  const [sceneIdx, setSceneIdx] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [selected, setSelected] = useState<Square | null>(null);
  const [line, setLine] = useState<LineRef | null>(null);
  const [ply, setPly] = useState(0);
  const [why, setWhy] = useState<WhyState | null>(null);
  const [hoverPoint, setHoverPoint] = useState<Marks | null>(null);
  const [hoverLine, setHoverLine] = useState<EngineLine | null>(null);
  const [pair, setPair] = useState<[number, number]>([1, 2]);
  const [animKey, setAnimKey] = useState(0);

  const lines = useMemo(() => a.snapshot?.lines ?? [], [a.snapshot]);
  const running = a.status === "running" || a.status === "starting";
  const done = a.status === "done" || a.status === "stopped";
  const turn = fen.split(" ")[1] as Color;

  const variation = useMemo(() => (line ? buildVariation(fen, line.pv, 24) : null), [fen, line]);
  const displayFen = variation ? fenAtPly(variation, ply) : fen;
  const atRoot = displayFen === fen;
  const lastMove = variation ? moveAtPly(variation, ply) : null;
  const displayTurn = displayFen.split(" ")[1] as Color;

  const lineFens = useMemo(() => (variation ? variation.moves.map((m) => m.fenAfter) : []), [variation]);
  const { requestPlyEvals } = a;
  useEffect(() => requestPlyEvals(lineFens), [lineFens, requestPlyEvals]);

  // Root facts use engine hints only once the search has settled, so the tour doesn't reshuffle mid-search.
  const rootHints = useMemo(() => (done && lines.length ? { firstMoves: lines.map((l) => l.pv[0]) } : undefined), [done, lines]);
  const rootFacts = useMemo(() => computeFacts(fen, rootHints), [fen, rootHints]);
  const rootEval: Evaluation | null = lines[0]?.eval ?? null;
  const extraThreats = useMemo(() => {
    if (!a.threat || !rootEval || !done) return [];
    const f = threatFact(fen, rootEval, a.threat);
    return f ? [f] : [];
  }, [a.threat, rootEval, done, fen]);
  const rootLedger = useMemo(() => buildLedger(rootFacts, extraThreats), [rootFacts, extraThreats]);

  const displayFacts = useMemo(() => {
    if (atRoot) return rootFacts;
    const pe = a.plyEval(displayFen);
    return computeFacts(displayFen, pe?.best ? { firstMoves: [pe.best] } : undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- plyVersion signals cache updates
  }, [atRoot, rootFacts, displayFen, a.plyVersion]);

  const bestFirst = useMemo(() => (lines[0] ? buildVariation(fen, lines[0].pv.slice(0, 1)).moves[0] : undefined), [fen, lines]);

  // The commentary on the analysed position: its types, each side's likes and dislikes, the plans.
  // The board's own reading comes at once; the engine's lines add the verdict and which plans it follows.
  const commentary = useMemo(
    () => buildCommentary(fen, done && lines.length ? { lines: lines.map((l) => ({ pv: l.pv, eval: l.eval, depth: l.depth })) } : undefined, rootFacts),
    [fen, done, lines, rootFacts],
  );

  // Deep understanding of the best move, started automatically once the search settles.
  const { requestDeep, deepFor } = a;
  useEffect(() => {
    if (!done || !lines[0]) return;
    requestDeep(lines[0], { isBest: true, alternatives: lines.slice(1) });
  }, [done, lines, requestDeep]);
  const bestDeep = done && lines[0] ? deepFor(lines[0].pv[0]) : null;

  // The guided tour: the best move and its ideas first, then the position's findings.
  const scenes: Scene[] = useMemo(() => {
    // After the best move's story, only what is concrete: threats, loose pieces, pins and forks.
    const base = buildTour(rootLedger, turn, 8).filter((sc) => sc.fact.lens === "threats");
    if (!done || !lines[0]) return base;
    const dm = bestDeep?.status === "done" ? bestDeep.data : bestDeep?.status === "failed" ? null : "pending";
    return [...deepScenes(fen, lines[0], dm), ...base];
    // eslint-disable-next-line react-hooks/exhaustive-deps -- deepVersion signals cache updates
  }, [rootLedger, turn, done, lines, fen, a.deepVersion]);

  const safeScene = Math.min(sceneIdx, Math.max(0, scenes.length - 1));

  // The side to move's plans that start with one move are checked by the engine; where the board
  // was measured for that move (lib/plans/cards), the plan carries those details too.
  const toMovePlans = commentary.sides[turn].plans;
  const timedPlans = useMemo((): TimedPlan[] => toMovePlans.filter((pl) => pl.keyUci).map((pl) => ({ id: pl.id, side: pl.side, title: pl.title, keyUci: pl.keyUci, keySan: pl.keySan, conditions: [] })), [toMovePlans]);
  const planDetails = useMemo(() => {
    const cards = findPlans(rootFacts.ctx, lines).map((pl) => planCard(fen, pl));
    const out: Record<string, PlanCard> = {};
    for (const c of ["w", "b"] as Color[])
      for (const pl of commentary.sides[c].plans) {
        const card = pl.key ? cards.find((x) => x.side === c && x.keyUci?.startsWith(`${pl.key!.from}${pl.key!.to}`)) : undefined;
        if (card) out[pl.id] = card;
      }
    return out;
  }, [commentary, rootFacts, lines, fen]);
  const bestLineInput = useMemo(() => (lines[0] ? { pv: lines[0].pv, eval: lines[0].eval, depth: lines[0].depth } : undefined), [lines]);
  const { timings: planTimings, threat: planThreat } = usePlanTimings(fen, timedPlans, bestLineInput, done && atRoot && tab === "plans");

  const shown = useMemo(() => {
    if (atRoot) return rootEval ? { e: rootEval, depth: lines[0]?.depth } : null;
    const pe = a.plyEval(displayFen);
    return pe ? { e: pe.eval, depth: pe.depth } : null;
    // eslint-disable-next-line react-hooks/exhaustive-deps -- plyVersion signals cache updates
  }, [atRoot, rootEval, lines, displayFen, a.plyVersion]);

  const stripEvals = useMemo(() => {
    if (!variation) return [];
    return [rootEval, ...variation.moves.map((m) => a.plyEval(m.fenAfter)?.eval ?? null)];
    // eslint-disable-next-line react-hooks/exhaustive-deps -- plyVersion signals cache updates
  }, [variation, rootEval, a.plyVersion]);

  const trace = useMemo(() => (selected ? traceSquare(displayFacts.ctx, selected) : null), [selected, displayFacts]);

  const selectLine = useCallback((l: LineRef, startPly = 1) => {
    setLine(l);
    setPly(startPly);
    setAnimKey((k) => k + 1);
    setSelected(null);
    setFocus(null);
    setShownPin(null);
    setPlaying(false);
  }, []);

  const nav = useCallback(
    (action: NavAction) => {
      if (!variation) return;
      setPly((p) => {
        const next = navigate(variation, p, action);
        if (next !== p) setAnimKey((k) => k + 1);
        return next;
      });
      setSelected(null);
    },
    [variation],
  );

  const openWhy = (l: LineRef) => {
    setTab("moves");
    setMovesMode("lines");
    selectLine(l, 1);
    setWhy({ kind: "why", line: l });
    requestDeep(l, { isBest: l.pv[0] === lines[0]?.pv[0], alternatives: lines.filter((x) => x.pv[0] !== l.pv[0]), bestLine: lines[0] });
  };

  const openWhyNot = (l: LineRef) => {
    setTab("moves");
    setMovesMode("lines");
    selectLine(l, 1);
    const best = lines[0];
    if (!best) return;
    setWhy({ kind: "whynot", line: l, data: explainWhyNot(fen, { pv: best.pv, eval: best.eval, depth: best.depth }, { pv: l.pv, eval: l.eval, depth: l.depth }) });
  };

  const tryMove = async (uci: string) => {
    setSelected(null);
    setTab("moves");
    setMovesMode("lines");
    const placeholder: LineRef = { key: `try-${uci}`, kind: "try", pv: [uci], eval: rootEval ?? { kind: "cp", cp: 0 }, depth: 0 };
    selectLine(placeholder, 1);
    setWhy({ kind: "whynot", line: placeholder, data: null, loading: true });
    const res = await a.analyzeMove(uci);
    if (!res || !res.pv.length) {
      setWhy({ kind: "whynot", line: placeholder, data: null, loading: false });
      return;
    }
    const ref: LineRef = { key: `try-${uci}`, kind: "try", pv: res.pv, eval: res.eval, depth: res.depth };
    setLine((cur) => (cur?.key === ref.key ? ref : cur));
    const best = lines[0];
    if (best && best.pv[0] !== uci) {
      setWhy({ kind: "whynot", line: ref, data: explainWhyNot(fen, { pv: best.pv, eval: best.eval, depth: best.depth }, { pv: ref.pv, eval: ref.eval, depth: ref.depth }) });
    } else {
      setWhy({ kind: "why", line: ref });
      requestDeep(ref, { isBest: true, alternatives: lines.filter((x) => x.pv[0] !== uci) });
    }
  };

  /** A move played on the board: from the analysed position it's explained; inside a line it continues the line. */
  const userMove = (uci: string) => {
    if (atRoot) return void tryMove(uci);
    const pv = [...(variation?.moves.slice(0, ply).map((m) => m.uci) ?? []), uci];
    selectLine({ key: `try-${pv.join("")}`, kind: "try", pv, eval: shown?.e ?? rootEval ?? { kind: "cp", cp: 0 }, depth: 0 }, pv.length);
  };

  // Top engine lines next to the board: the main search at the analysed position, a live search elsewhere in a line.
  const live = useLiveLines(displayFen, { enabled: !atRoot });
  const boardLines = atRoot ? lines : (live?.lines ?? []);
  const playFromBoard = (pv: string[], upto: number) => {
    const prefix = atRoot ? [] : (variation?.moves.slice(0, ply).map((m) => m.uci) ?? []);
    const full = [...prefix, ...pv];
    selectLine({ key: `side-${full.join("")}`, kind: "side", pv: full, eval: boardLines.find((l) => l.pv === pv)?.eval ?? rootEval ?? { kind: "cp", cp: 0 }, depth: 0 }, prefix.length + upto);
  };

  /** Play a line from the analysed position; an empty pv means "the line of the open explanation". */
  const playLine = (pv: string[], toPly: number) => {
    if (!pv.length) {
      const l = why?.line;
      if (l && line?.key !== l.key) selectLine(l, toPly);
      else {
        setPly(toPly);
        setAnimKey((k) => k + 1);
      }
      return;
    }
    const ref: LineRef = { key: `side-${pv.join("")}`, kind: "side", pv, eval: rootEval ?? { kind: "cp", cp: 0 }, depth: 0 };
    selectLine(ref, toPly);
  };

  const closeLine = () => {
    setLine(null);
    setPly(0);
    setWhy(null);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
      if (e.key === "ArrowRight") nav("next");
      else if (e.key === "ArrowLeft") nav("prev");
      else if (e.key === "Home") nav("first");
      else if (e.key === "End") nav("last");
      else if (e.key === "Escape") {
        setSelected(null);
        setFocus(null);
        setShownPin(null);
        setHoverPoint(null);
      } else return;
      e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [nav]);

  // One spotlight decides what the board shows, most specific first.
  const spot = useMemo((): { marks: Marks; key: string; caption: CaptionData | null } => {
    if (hoverPoint) return { marks: hoverPoint, key: "point", caption: null };
    // A remark or a plan from the commentary: what the mouse is on, else what was tapped.
    const remark = (tab === "overview" || tab === "plans") && atRoot ? (shownHover ?? shownPin) : null;
    if (remark) return { marks: remark.marks, key: `remark-${remark.id}`, caption: { key: remark.id, tone: remark.tone, tag: remark.tone === "opportunity" ? "+" : remark.tone === "danger" ? "−" : "•", kind: remark.kind, text: remark.text } };
    if (hoverFact) return { marks: hoverFact.marks, key: `h-${hoverFact.id}`, caption: factCaption(hoverFact) };
    if (hoverLine && atRoot) {
      const m = emptyMarks();
      const u = hoverLine.pv[0];
      if (u) m.arrows.push({ from: u.slice(0, 2) as Square, to: u.slice(2, 4) as Square, tone: "opportunity" });
      return { marks: m, key: `line-${u}`, caption: null };
    }
    if (trace) {
      return {
        marks: trace.marks,
        key: `trace-${trace.sq}`,
        caption: { key: `trace-${trace.sq}`, tone: "white", tag: "◎", kind: "Tracing", text: trace.lines.join(" ") },
      };
    }
    const nextHint = (m: Marks) => {
      if (variation && ply < variation.moves.length) {
        const nx = variation.moves[ply];
        m.arrows.push({ from: nx.from, to: nx.to, tone: "info", thin: true, dashed: true });
      }
      return m;
    };
    const moveCaption = (): CaptionData | null => {
      if (!lastMove) return null;
      const num = lastMove.color === "w" ? `${lastMove.moveNumber}.` : `${lastMove.moveNumber}…`;
      // The first move of a line with a finished deep analysis gets the deep headline, not a one-move guess.
      const deep = ply === 1 && lastMove.fenBefore === fen ? deepFor(lastMove.uci) : null;
      if (deep?.status === "done") {
        const d = deep.data;
        return { key: `mv-${ply}-${line?.key}-deep`, tone: "opportunity", tag: d.classification.symbol || `${ply}`, kind: `${d.classification.label} · ${num}${lastMove.san}`, text: d.headline };
      }
      const ideas = boardIdeas(lastMove, { after: variation ? variation.moves.slice(ply) : [], evalAfter: 0 });
      const best = ideas.find((p) => p.tone !== "danger") ?? ideas[0];
      return {
        key: `mv-${ply}-${line?.key}`,
        tone: best?.tone === "info" ? "info" : (best?.tone ?? "info"),
        tag: `${ply}`,
        kind: `${sideName(lastMove.color)} plays ${num}${lastMove.san}`,
        text: best?.text ?? "A quiet move: its point comes later in the line.",
      };
    };
    if (tab === "story" && atRoot) {
      const s = scenes[safeScene];
      if (s) {
        const cap = factCaption(s.fact, s.polarity);
        return { marks: s.fact.marks, key: `scene-${s.id}`, caption: s.kicker ? { ...cap, kind: s.kicker, tag: s.id === "deep-move" ? "★" : cap.tag } : cap };
      }
    }
    if (tab === "layers") {
      const all = { ...displayFacts, byLens: { ...displayFacts.byLens, threats: atRoot ? [...extraThreats, ...displayFacts.byLens.threats] : displayFacts.byLens.threats } };
      const m = marksForLenses(all, lenses, focus);
      const f = focus ? Object.values(all.byLens).flat().find((x) => x.id === focus) : null;
      const n = lenses.reduce((s2, l) => s2 + all.byLens[l].length, 0);
      return {
        marks: nextHint(m),
        key: `layers-${lenses.join("")}-${focus}-${displayFen}`,
        caption: f
          ? factCaption(f)
          : lenses.length
            ? { key: `l-${lenses.join("")}`, tone: "info", tag: String(n), kind: `${lenses.length} layer${lenses.length > 1 ? "s" : ""} on`, text: "Hover a finding to isolate it on the board, or tap a piece to trace it." }
            : moveCaption(),
      };
    }
    // Reading the commentary with nothing picked: the engine's move, so the story's words have a picture.
    if ((tab === "overview" || tab === "plans") && atRoot && done && bestFirst) {
      const m = emptyMarks();
      m.arrows.push({ from: bestFirst.from, to: bestFirst.to, tone: "opportunity" });
      return { marks: m, key: `best-${bestFirst.uci}`, caption: null };
    }
    if (tab === "moves" && movesMode === "compare" && atRoot && lines.length >= 2) {
      const m = emptyMarks();
      const la = lines.find((l) => l.multipv === pair[0]);
      const lb = lines.find((l) => l.multipv === pair[1]);
      if (la?.pv[0]) m.arrows.push({ from: la.pv[0].slice(0, 2) as Square, to: la.pv[0].slice(2, 4) as Square, tone: "opportunity" });
      if (lb?.pv[0]) m.arrows.push({ from: lb.pv[0].slice(0, 2) as Square, to: lb.pv[0].slice(2, 4) as Square, tone: "white" });
      return { marks: m, key: `cmp-${pair.join("")}`, caption: null };
    }
    return { marks: nextHint(emptyMarks()), key: `plain-${ply}`, caption: moveCaption() };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- deepVersion signals deep-cache updates
  }, [hoverPoint, shownHover, shownPin, hoverFact, hoverLine, atRoot, trace, variation, ply, lastMove, line, tab, scenes, safeScene, displayFacts, extraThreats, lenses, focus, displayFen, done, bestFirst, movesMode, lines, pair, fen, deepFor, a.deepVersion]);

  const toggleLens = (id: LensId) => {
    setFocus(null);
    setSelected(null);
    setLenses((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));
  };
  const cleanBoard = () => {
    if (lenses.length) {
      setSavedLenses(lenses);
      setLenses([]);
    } else setLenses(savedLenses.length ? savedLenses : ["threats"]);
    setFocus(null);
    setSelected(null);
  };

  const context =
    variation && ply > 0 && lastMove
      ? `After ${lastMove.color === "w" ? `${lastMove.moveNumber}.` : `${lastMove.moveNumber}…`}${lastMove.san} · ${sideName(displayTurn)} to move`
      : `${sideName(turn)} to move · move ${fen.split(" ")[5]}`;
  const progress = settings.depth ? Math.min(1, (a.snapshot?.depth ?? 0) / settings.depth) : Math.min(1, (a.snapshot?.elapsedMs ?? 0) / (settings.movetimeMs ?? 1));
  // Story chapters can preview a position inside a line (e.g. "if the pawn is taken…").
  const storyScene = tab === "story" && atRoot ? scenes[safeScene] : undefined;
  const preview = useMemo(() => {
    if (!storyScene?.preview) return null;
    const pv = buildVariation(fen, storyScene.preview.pv, 24);
    return { fen: fenAtPly(pv, storyScene.preview.ply), move: moveAtPly(pv, storyScene.preview.ply) };
  }, [storyScene, fen]);
  const boardFen = preview?.fen ?? displayFen;
  const boardMove = preview ? preview.move : lastMove;
  const placement = useMemo(() => placementFromFen(boardFen), [boardFen]);
  const rootPlacement = useMemo(() => placementFromFen(fen), [fen]);
  const threatCount = [...rootLedger.w.weaknesses, ...rootLedger.b.weaknesses].filter((e) => THREAT_KINDS.includes(e.fact.kind)).length;

  const TABS: [Tab, string, number | null][] = [
    ["overview", "Overview", null],
    ["plans", "Plans", commentary.sides.w.plans.length + commentary.sides.b.plans.length || null],
    ["story", "Best move", scenes.length || null],
    ["moves", "Moves", lines.length || null],
    ["layers", "Layers", null],
  ];

  // Line previews (hover a move in an explanation) use the board's orientation.
  return (
    <PeekOrientation.Provider value={orientation}>
      {!introDone && (
        <ScanIntro placement={rootPlacement} orientation={orientation} ledger={rootLedger} threats={threatCount} depth={a.snapshot?.depth ?? 0} onDone={() => setIntroDone(true)} />
      )}
      <main className="arena">
        <Scoreboard
          headline={atRoot ? commentary.headline : null}
          story={atRoot ? commentary.story : []}
          evaluation={shown?.e ?? null}
          depth={shown?.depth}
          context={context}
          status={a.status}
          snapshot={a.snapshot}
          error={a.error}
          presetIdx={presetIdx}
          onPreset={setPresetIdx}
          multipv={multipv}
          onMultipv={setMultipv}
          onStop={a.cancel}
          onRerun={a.rerun}
          progress={running ? progress : done ? 1 : 0}
        />

        <section className="board-col" aria-label="Board">
          <div className="board-bar">
            <span className="board-title">{context}</span>
            <button className="btn btn-sm btn-ghost" onClick={() => onOrientation(other(orientation))}>
              Flip ⇅
            </button>
          </div>
          <div className="board-wrap">
            <EvalBar e={shown?.e ?? null} orientation={orientation} />
            <PlayBoard
              fen={displayFen}
              onMove={userMove}
              onSelect={(sq) => {
                setPlaying(false);
                setSelected(sq);
              }}
              placement={placement}
              orientation={orientation}
              marks={spot.marks}
              revealKey={`${spot.key}-${animKey}`}
              lastMove={boardMove ? { from: boardMove.from, to: boardMove.to } : null}
              animate={boardMove ? { from: boardMove.from, to: boardMove.to, key: `${animKey}-${storyScene?.id ?? ""}` } : null}
              label={`Chess position, ${sideName(displayTurn)} to move`}
              dimPieces={!!hoverPoint}
            />
          </div>
          <Caption c={spot.caption} />
          {selected && displayFacts.ctx.legal.some((m) => m.from === selected) && (
            <p className="hint" style={{ textAlign: "center" }}>
              Drag the piece or tap a dotted square to play it; the engine answers. Right-click to draw arrows and circles.
            </p>
          )}
          {variation && (
            <VariationBar
              variation={variation}
              ply={ply}
              onNav={nav}
              evals={stripEvals}
              title={line?.kind === "try" ? "Your move, played out" : line?.kind === "side" ? "Side line" : `Engine line ${line?.rank ?? ""}`}
              onClose={closeLine}
            />
          )}
        </section>

        <aside className="desk" aria-label="Analysis">
          <div className="tabs" role="tablist">
            {TABS.map(([id, label, count]) => (
              <button
                key={id}
                role="tab"
                aria-selected={tab === id}
                className={tab === id ? "tab tab-on" : "tab"}
                onClick={() => {
                  setTab(id);
                  setHoverFact(null);
                  setShownHover(null);
                  setShownPin(null);
                }}
              >
                {label}
                {count ? <span className="count">{count}</span> : null}
              </button>
            ))}
          </div>

          {a.status === "error" && (
            <div className="notice notice-error" role="alert">
              <p>
                <b>Stockfish couldn&apos;t run.</b> {a.error}
              </p>
              <p className="small muted" style={{ margin: 0 }}>
                The overview, plans and layers still work: they come from the board itself. Try Re-run, or a current browser.
              </p>
            </div>
          )}

          {tab === "overview" && (
            <OverviewPanel
              commentary={commentary}
              turn={turn}
              settled={done}
              pinned={shownPin?.id ?? null}
              onHover={setShownHover}
              onPin={(x) => {
                setShownPin(x);
                setSelected(null);
              }}
              offRoot={!atRoot}
              onBackToRoot={closeLine}
            />
          )}

          {tab === "plans" && (
            <StrategyPanel
              commentary={commentary}
              turn={turn}
              timings={planTimings}
              details={planDetails}
              threat={atRoot ? planThreat : null}
              bestSan={bestFirst?.san ?? null}
              pinned={shownPin?.id ?? null}
              onHover={setShownHover}
              onPin={(x) => {
                setShownPin(x);
                setSelected(null);
              }}
              onShow={(pv) => playLine(pv, 1)}
              offRoot={!atRoot}
              onBackToRoot={closeLine}
            />
          )}

          {tab === "story" && (
            <StoryPanel
              scenes={scenes}
              index={safeScene}
              onIndex={(i) => {
                setSceneIdx(i);
                setSelected(null);
              }}
              playing={playing && introDone && bestDeep?.status !== "pending"}
              onPlaying={setPlaying}
              offRoot={!atRoot}
              onBackToRoot={closeLine}
            />
          )}

          {tab === "moves" && (
            <div className="desk-body" style={{ display: "grid", gap: 10 }}>
              <div className="tabs" role="tablist" aria-label="Moves view">
                {(
                  [
                    ["lines", "Best lines"],
                    ["compare", "Compare"],
                    ["quiz", "Try it first"],
                  ] as [MovesMode, string][]
                ).map(([id, label]) => (
                  <button key={id} role="tab" aria-selected={movesMode === id} className={movesMode === id ? "tab tab-on" : "tab"} onClick={() => setMovesMode(id)}>
                    {label}
                  </button>
                ))}
              </div>
              {movesMode === "lines" && (
                <LinesPanel
                  fen={fen}
                  lines={lines}
                  running={running}
                  selectedKey={line?.key ?? null}
                  onSelect={(l) => {
                    setWhy(null);
                    selectLine(l, 1);
                  }}
                  onHoverLine={setHoverLine}
                  onWhy={openWhy}
                  onWhyNot={openWhyNot}
                  why={why}
                  onCloseWhy={() => setWhy(null)}
                  onHoverPoint={setHoverPoint}
                  deepFor={deepFor}
                  onPlay={playLine}
                  onShowPly={(p) => {
                    setPly(p);
                    setAnimKey((k) => k + 1);
                  }}
                />
              )}
              {movesMode === "compare" && <ComparePanel fen={fen} lines={lines} orientation={orientation} pair={pair} onPair={setPair} />}
              {movesMode === "quiz" && <QuizPanel fen={fen} lines={lines} done={done} onWhy={openWhy} onWhyNot={openWhyNot} />}
            </div>
          )}

          {tab === "layers" && (
            <LayersPanel
              facts={displayFacts}
              active={lenses}
              onToggle={toggleLens}
              onClean={cleanBoard}
              focus={focus}
              onFocus={(id) => {
                setFocus(id);
                setSelected(null);
              }}
              onHover={setHoverFact}
              extraThreats={atRoot ? extraThreats : []}
            />
          )}

          <EngineLines
            fen={displayFen}
            lines={boardLines}
            depth={boardLines[0]?.depth ?? null}
            searching={atRoot ? running : !!live && !live.done}
            onPlay={playFromBoard}
            onHover={setHoverPoint}
          />
          <footer className="desk-foot">
            <button className="linkish" onClick={onEdit}>
              Edit this position
            </button>
            <span className="fen-mini" title={fen}>
              {fen}
            </span>
          </footer>
        </aside>
      </main>
    </PeekOrientation.Provider>
  );
}
